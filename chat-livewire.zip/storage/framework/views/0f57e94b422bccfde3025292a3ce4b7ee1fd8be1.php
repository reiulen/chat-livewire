<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('message')->html();
} elseif ($_instance->childHasBeenRendered('nNljGXo')) {
    $componentId = $_instance->getRenderedChildComponentId('nNljGXo');
    $componentTag = $_instance->getRenderedChildComponentTagName('nNljGXo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nNljGXo');
} else {
    $response = \Livewire\Livewire::mount('message');
    $html = $response->html();
    $_instance->logRenderedChild('nNljGXo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chat-livewire\resources\views/home.blade.php ENDPATH**/ ?>