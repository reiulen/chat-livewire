<div class="container">
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-header">
                    <h4>Chat</h4>
                </div>
                <div class="card-body">
                    <div class="list-group list-group-flush">
                        <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div wire:click="selectGroup(<?php echo e($row->id); ?>)" role="button" class="list-group-item"><?php echo e($row->nama); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
         <?php if($groups != NULL): ?>
             <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($groups->nama); ?></div>
                    <div class="card-body">
                        <div wire:poll.1ms class="list-group list-group-flush mb-4" style="max-height: 300px; overflow:auto; display:flex; flex-direction: column-reverse;">
                            <?php $__currentLoopData = $chat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item <?php echo e($row->user->id == $user->id ? 'text-end' : ''); ?>">
                                <div class="text-muted text-small" style="font-size: 14px">[<?php echo e($row->created_at); ?>] <?php echo e($row->User->name); ?></div>
                                <div><?php echo e($row->pesan); ?></div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="form-group d-flex">
                            <input wire:model="pesan" name="pesan" type="text" class="form-control <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Kirim pesan...." />
                            <button wire:click="kirim" class="btn btn-primary mx-2">Kirim</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
         <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\chat-livewire\resources\views/livewire/message.blade.php ENDPATH**/ ?>