<div class="container">
   <div class="row">
        <div class="col-md-8 my-5 mx-auto">
            <div class="card">
                <div class="card-header">Mau chat sama siapa?</div>
                <div class="card-body">
                    <div class="form-group mb-4">
                        <select wire:model="nama" class="form-control  <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama" id="nama">
                            <option selected disabled>- Pilih user -</option>
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group mb-4">
                        <button wire:click="mulai" class="btn btn-primary">Chat sekarang</button>
                    </div>
                </div>
            </div>
        </div>
   </div>
</div>
<?php /**PATH C:\xampp\htdocs\chat-livewire\resources\views/livewire/home.blade.php ENDPATH**/ ?>