<?php $__env->startSection('content'); ?>
<?php $__env->startSection('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home')->html();
} elseif ($_instance->childHasBeenRendered('g0I9B1T')) {
    $componentId = $_instance->getRenderedChildComponentId('g0I9B1T');
    $componentTag = $_instance->getRenderedChildComponentTagName('g0I9B1T');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('g0I9B1T');
} else {
    $response = \Livewire\Livewire::mount('home');
    $html = $response->html();
    $_instance->logRenderedChild('g0I9B1T', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->startSection('script'); ?>
<script src="https://e-filling.smkn1ciamis.id/assets/plugins/jquery/jquery.min.js"></script>
<script src="https://e-filling.smkn1ciamis.id/assets/plugins/select2/js/select2.min.js"></script>
    <script>
        $('#nama').select2();
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chat-livewire\resources\views/welcome.blade.php ENDPATH**/ ?>