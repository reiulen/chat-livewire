<?php return array (
  'home' => 'App\\Http\\Livewire\\Home',
  'message' => 'App\\Http\\Livewire\\Message',
);