@extends('layouts.app')

@section('content')
@livewire('message')
@endsection
